<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>RailTicket - <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="flex flex-col w-screen h-screen ">
    <div class=" flex justify-between w-screen h-[10%] bg-[#d55257] p-3">
        <?php echo $__env->yieldContent('nav'); ?>
    </div>
    <div class="flex w-screen h-[50%] bg-[#d55257]">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <div class="w-screen h-[10%]">
        <?php echo $__env->yieldContent('footer'); ?>
    </div>

</body>

</html>
<?php /**PATH D:\Documents\Training_Atpl\Day40\RailTicket\resources\views/layouts/app.blade.php ENDPATH**/ ?>