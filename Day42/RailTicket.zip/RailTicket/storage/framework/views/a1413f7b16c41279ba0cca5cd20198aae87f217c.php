
<?php $__env->startSection('title', 'User Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
    <div class="flex flex-1 text-center items-center h-[100%]">
        <div class=" w-[10%] bg-[url('/public/icon.png')] h-[100%] bg-no-repeat bg-contain bg-left"></div>
        <h1 class="ml-5 text-white font-bold hover:border-b-2 ">RAILTICKET</h1>
        <h2 class="ml-5 text-white hover:font-bold hover:border-b-2 ">Find your next train</h2>
    </div>
    <div class=" flex flex-1 items-center h-[100%] justify-end">
        <a href="/userDashboard">
            <h1 class="mr-5 text-white hover:font-bold hover:border-b-2 ">Welcome <?php echo e($user = session()->get('user')->name); ?>

            </h1>
        </a>
        <a href="/logout">
            <h2 class="mr-5 text-white hover:font-bold hover:border-b-2 ">Logout</h2>
        </a>
        <a href="/view-tickets">
            <h2 class="mr-5 text-white hover:font-bold border-b-2 ">Tickets</h2>
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="flex pl-[100px] justify-end items-center flex-1 bg-[url('/public/kohli.png')] bg-no-repeat bg-contain bg-left ">

        <form action="/book-tickets" id="div1" method="post"
            class="flex flex-col justify-around items-center h-[100%] ">
            <?php echo csrf_field(); ?>
            <h2 class="text-xl text-white text-center ">Add Pessengers (*Min: 1 and *Max: 5)</h2>
            <div class="">
                <input type="text" name="name1" placeholder="Name of Passenger1" class="pr-20 pl-5 pt-2.5 pb-2.5"
                    required>
                <input type="text" name="age1" placeholder="Age" class="pt-2.5 pb-2.5" required>
                <input type="text" name="gender1" placeholder="Gender" class="pt-2.5 pb-2.5" required>
                <input type="email" name="email1" placeholder="Email" class="pt-2.5 pb-2.5" required>
            </div>

            <input type="submit" value="BOOK"
                class=" bg-[#ff5d5d] shadow-md pt-2.5 pb-2.5 pl-5 pr-5 rounded-sm text-white font-bold ">
        </form>
        <?php $train = Session::get('train');
        $error = Session::get('error');
        $tickets = Session::get('tickets');
        ?>
    </div>
    <div class="flex items-center w-[25%] bg-[url('/public/train.png')] bg-no-repeat bg-contain bg-right ">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('results'); ?>
    <?php if($error): ?>
        <div class="flex flex-1 items-center justify-center">
            <h1 class=""><?php echo e($error); ?></h1>
        </div>
    <?php elseif($tickets): ?>
        <div class="flex w-screen h-[100%] items-center justify-around">
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php $passenger = DB::table('passengers')
                    ->where('id', $ticket->passenger_id)
                    ->get(); ?>
                <div
                    class="flex flex-col h-[80%] justify-around items-center rounded-md m-3 text-white w-[25%] bg-[#3d95c5]">
                    <h1 class="text-black text-center">Ticket ID: <?php echo e($ticket->id); ?></h1>
                    <h1 class="text-black text-center">Train ID: <?php echo e($ticket->train_id); ?></h1>
                    <h1 class="text-black text-center">Seat Number: <?php echo e($ticket->seat_number); ?></h1>
                    <h1 class="text-black text-center">Journey Date: <?php echo e($ticket->journey_date); ?></h1>
                    <h1 class="text-black text-center">Price: <?php echo e($ticket->price); ?></h1>
                    <h1 class="text-black text-center">Passenger Name: <?php echo e($passenger[0]->name); ?></h1>
                    <h1 class="text-black text-center">Passenger Age: <?php echo e($passenger[0]->age); ?></h1>
                    <h1 class="text-black text-center">Passenger Gender: <?php echo e($passenger[0]->gender); ?></h1>
                    <a href=""
                        class="bg-[#ff5d5d] shadow-md pt-2.5 pb-2.5 pl-5 pr-5 rounded-sm text-white font-bold">Print</a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="flex flex-1 items-center justify-center">
            <h1 class=""><?php echo e($train); ?></h1>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Training_Atpl\Day42\RailTicket\resources\views/viewTickets.blade.php ENDPATH**/ ?>